const bodyParser = require('body-parser');
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const app = express();
const PORT = process.env.PORT || 3010;
app.use(cors());


const session = require("express-session");
const passport = require("passport");
const LocalStrategy = require("passport-local");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
// const { Strategy, ExtractJwt } = require("passport-jwt");
const JwtStrategy = require('passport-jwt').Strategy;
const ExtractJwt = require('passport-jwt').ExtractJwt;

const pgp = require("pg-promise")({});

const usuario = "postgres";
const senha = "teste123";
const db = pgp(`postgres://${usuario}:${senha}@localhost:5432/trabint`);




app.use(bodyParser.json());
app.use(express.json());


app.get('/', (req, res) => {
	res.send('Servidor backend funcionando!');
});

app.listen(PORT, () => {
	console.log(`Servidor backend rodando na porta ${PORT}`);
});

app.use(
	session({
		secret: 'frase_secreta',
		resave: false,
		saveUninitialized: false,
		cookie: { secure: true },
	}),
);
app.use(passport.initialize());
app.use(passport.session());

passport.use(
	new LocalStrategy(
		{
			usernameField: "cpf",
			passwordField: "senha",
		},
		async (username, password, done) => {
			try {
				// busca o usuário no banco de dados
				const user = await db.oneOrNone(
					"SELECT * FROM usuarios WHERE cpf = $1;",
					[username],
				);

				// se não encontrou, retorna erro
				if (!user) {
					return done(null, false, { message: "Usuário incorreto." });
				}

				// verifica se o hash da senha bate com a senha informada
				const passwordMatch = await bcrypt.compare(
					password,
					user.senha,
				);

				// se senha está ok, retorna o objeto usuário
				if (passwordMatch) {
					console.log("Usuário autenticado!");
					return done(null, user);
				} else {
					// senão, retorna um erro
					return done(null, false, { message: "Senha incorreta." });
				}
			} catch (error) {
				return done(error);
			}
		},
	),
);

passport.use(
	new JwtStrategy(
		{
			jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
			secretOrKey: "your-secret-key",
		},
		async (payload, done) => {
			try {
				const user = await db.oneOrNone(
					"SELECT * FROM usuarios WHERE cpf = $1;",
					[payload.cpf],
				);

				if (user) {
					done(null, user);
				} else {
					done(null, false);
				}
			} catch (error) {
				done(error, false);
			}
		},
	),
);

passport.serializeUser(function (user, cb) {
	process.nextTick(function () {
		return cb(null, {
			id: user.id,
			cpf: user.cpf,
		});
	});
});

passport.deserializeUser(function (user, cb) {
	process.nextTick(function () {
		return cb(null, user);
	});
});

const requireJWTAuth = passport.authenticate("jwt", { session: false });

app.post(
	"/login",
	passport.authenticate("local", { session: false }),
	(req, res) => {

		// Cria o token JWT
		const token = jwt.sign({ cpf: req.body.cpf }, "your-secret-key", {
			expiresIn: "1h",
		});
		res.json({ message: "Login successful", token: token });
	},
);

app.post("/cadastrar", async (req, res) => {
	const saltRounds = 10;
	try {
		const cpf = req.body.cpf;
		const senha = req.body.senha;
		const salt = bcrypt.genSaltSync(saltRounds);
		const hashedPasswd = bcrypt.hashSync(senha, salt);

		console.log(`Cpf: ${cpf} - Passwd: ${hashedPasswd}`);
		await db.none("INSERT INTO usuarios (cpf, senha) VALUES ($1, $2);", [
			cpf,
			hashedPasswd,
		]);
		res.sendStatus(200);
	} catch (error) {
		console.log(error);
		res.sendStatus(400);
	}
});

app.put("/saldo", async (req, res) => {

	const saldoNovo = parseFloat(req.body.saldo);
	if (isNaN(saldoNovo)) {
		res.status(400).send("O saldo fornecido não é um número válido.");
		return;
	}
	try {
		await db.none("UPDATE saldo SET saldo = saldo + $1 ", [
			saldoNovo,
		]);
		res.sendStatus(200);
	} catch (error) {
		console.log(error);
		res.sendStatus(400);
	}
});

app.get("/saldo", async (req, res) => {
	try {
		const saldo = await db.one("SELECT saldo FROM saldo;");
		res.json(saldo);
	} catch (error) {
		console.log(error);
		res.status(500).json({ error: "Erro ao recuperar o saldo do banco de dados." });
	}
});

app.get("/estoque", async (req, res) => {
	try {
		const estoque = await db.any("SELECT * FROM estoque;");
		res.json(estoque);
	} catch (error) {
		console.log(error);
		res.status(500).json({ error: "Erro ao recuperar o estoque do banco de dados." });
	}
});

app.delete('/estoque', async (req, res) => {
	const item = req.body.item;
	const preco = req.body.preco;
	const quantidade = req.body.quantidade;
	
	try {
		await db.none('DELETE FROM estoque WHERE item= $1 AND preco= $2 AND quantidade= $3', [item, preco, quantidade]);
		console.log('Itens removidos com sucesso!');
		res.status(200).json({ message: 'Itens removidos com sucesso!' });
	} catch (error) {
		console.error('Erro ao remover itens do banco de dados:', error);
		res.status(500).json({ error: 'Erro ao remover itens do banco de dados' });
	}
});

app.post("/estoque", async (req, res) => {
	const item = req.body.item;
	const preco = req.body.preco;
	const quantidade = req.body.quantidade;

	try {
		await db.none('INSERT INTO estoque (item, preco, quantidade) VALUES ($1,$2,$3)', [item, preco, quantidade]);
		console.log('Item atualizado com sucesso!');
		res.sendStatus(200);
	} catch (error) {
		console.error(error);
		res.sendStatus(400);
	}
});

app.put("/estoque", async (req, res) => {
    const row = req.body;
    const novoPreco = req.body.novopreco;
    const novaQuantidade = req.body.novaquantidade;

    try {
        await db.none('UPDATE estoque SET preco = $1, quantidade = $2 WHERE item = $3', [novoPreco, novaQuantidade, row.item]);
        console.log('Item atualizado com sucesso!');
        res.sendStatus(200);
    } catch (error) {
        console.error(error);
        res.sendStatus(400);
    }
});




