import * as React from 'react';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableSortLabel from '@mui/material/TableSortLabel';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import Checkbox from '@mui/material/Checkbox';

import { Modal, Grid, Input} from '@mui/material';
import { styled } from '@mui/system';

import '../styles.css';

import axios from 'axios';

const StyledModal = styled(Modal)`
  display: flex;
  align-items: center;
  justify-content: center;
`;

const StyledPaper = styled(Paper)`
  position: absolute;
  width: 400px;
  padding: 16px;
  outline: none;
`;

const StyledInput = styled(Input)`
  width: 100%;
  margin-bottom: 16px;
`;

const fetchDataFromDatabase = async () => {
    try {
        const response = await fetch('http://localhost:3010/estoque');
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Erro ao buscar dados do banco de dados:', error);
        return [];
    }
};

function createData(id, item, preco, quantidade) {
    return {
        id,
        item,
        preco,
        quantidade,
    };
}

export default function EnhancedTable() {
    const [order, setOrder] = React.useState('asc');
    const [orderBy, setOrderBy] = React.useState('preco');
    const [open, setOpen] = React.useState(false);
    const [rows, setRows] = React.useState([]);
    const [rowSeleted, setRowSeleted] = React.useState();

    React.useEffect(() => {
        const fetchData = async () => {
            const data = await fetchDataFromDatabase();
            const formattedData = data.map((item, index) =>
                createData(index + 1, item.item, item.preco, item.quantidade)
            );
            setRows(formattedData);
        };
        fetchData();
    }, []);

    const handleRequestSort = (event, property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
        setRows((prevRows) => {
            return prevRows.slice().sort((a, b) => {
                const aValue = typeof a[property] === 'number' ? a[property] : parseFloat(a[property]) || 0;
                const bValue = typeof b[property] === 'number' ? b[property] : parseFloat(b[property]) || 0;
                if (isAsc) {
                    return aValue - bValue;
                } else {
                    return bValue - aValue;
                }
            });
        });
    };

    const handleSelect = (row) => {
        setRowSeleted(row);
        console.log('Selecionado:', rowSeleted);
    };

    const remover = async () => {
        try {
            const resposta = await axios.delete(`http://localhost:3010/estoque`, { data: rowSeleted });
            console.log(resposta);
            window.location.reload();
        } catch (error) {
            console.error('Erro ao remover item:', error);
        }
    };

    const ModalEdit = ({ isOpen, onClose, rowSeleted }) => {
        const [novopreco, setNovoPreco] = React.useState('');
        const [novaquantidade, setNovaQuantidade] = React.useState('');
        
        const handleSaveChanges = async () => {
            const dataToSend = { ...rowSeleted, novopreco, novaquantidade };
            console.log('Dados a serem enviados:', dataToSend);
            try {
                const response = await axios.put("http://localhost:3010/estoque", dataToSend);
                if (response.status === 200) {
                    console.log('Item editado com sucesso!');
                    onClose();
                    window.location.reload();
                } else {
                    console.error('Erro ao editar item. Status:', response.status);
                }
            } catch (error) {
                console.error('Erro ao editar item:', error);
            }
        };
        return (
            <StyledModal open={isOpen} onClose={onClose}>
                <StyledPaper>
                    <Typography variant="h6" gutterBottom>
                        Editar Item
                    </Typography>
                    <Grid container spacing={2}>
                        <Grid item xs={12}>
                            <StyledInput
                                type="number"
                                value={novopreco}
                                onChange={(e) => setNovoPreco(e.target.value)}
                                placeholder="Preço"
                                input={{ min: 0 }}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <StyledInput
                                type="number"
                                value={novaquantidade}
                                onChange={(e) => setNovaQuantidade(e.target.value)}
                                placeholder="Quantidade"
                                input={{ min: 0 }}
                            />
                        </Grid>
                    </Grid>
                    <Box mt={2}>
                        <Button variant="contained" onClick={onClose} sx={{ marginRight: 2 }}>
                            Cancelar
                        </Button>
                        <Button variant="contained" onClick={handleSaveChanges}>
                            Salvar
                        </Button>
                    </Box>
                </StyledPaper>
            </StyledModal>
        );
    };
    
    const openModal = () => {
        setOpen(true);
    };
    const closeModal = () => {
        setOpen(false);
    };

    return (
        <Box justifyContent="space-between" alignItems="center" sx={{ width: '100%' }}>
            <Paper sx={{ width: '100%', mb: 2 }}>
                <Toolbar
                    sx={{
                        pl: { sm: 2 },
                        pr: { xs: 1, sm: 1 },
                    }}
                    >
                    <Typography
                        sx={{ flex: '1 1 100%' }}
                        variant="h6"
                        id="tableTitle"
                        component="div"
                    >
                        <b>Itens disponíveis no estoque</b>
                    </Typography>
                </Toolbar>
                <TableContainer>
                    <Table
                        sx={{ minWidth: 750 }}
                        aria-labelledby="tableTitle"
                    >
                        <TableHead>
                            <TableRow>
                                <TableCell padding="checkbox"></TableCell>
                                <TableCell
                                    align="left"
                                    padding="normal"
                                    sortDirection={orderBy === 'item' ? order : false}>
                                    <b>Item</b>
                                </TableCell>
                                <TableCell align="right"><b>Preço</b></TableCell>
                                <TableCell align="right">
                                    <TableSortLabel
                                        active={orderBy === 'quantidade'}
                                        direction={order}
                                        onClick={(event) => handleRequestSort(event, 'quantidade')}
                                    >
                                        <b>Quantidade</b>
                                    </TableSortLabel>
                                </TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {rows.map((row) => (
                                <TableRow
                                    hover
                                    key={row.id}
                                >
                                    <TableCell padding="checkbox">
                                        <Checkbox
                                            color="primary"
                                            checked={rowSeleted === row}
                                            onChange={() => handleSelect(row)}
                                            style={{ color: 'primary.main' }}
                                        />
                                    </TableCell>
                                    <TableCell align="left" padding="normal">
                                        {row.item}
                                    </TableCell>
                                    <TableCell align="right">{row.preco}</TableCell>
                                    <TableCell align="right">{row.quantidade}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Paper>
            <Button variant="contained" onClick={() => openModal()}>Editar</Button>
            <Button onClick={remover}> Remover </Button>
            {open && (
                <ModalEdit isOpen={openModal} onClose={closeModal} rowSeleted={rowSeleted} />
            )}
        </Box>
    );
}
