import React from "react";
import axios from "axios";
import '../styles.css';
import Logo from "../logo.png";
import { useNavigate } from "react-router-dom";
import { Button, Input, Alert, AlertTitle } from "@mui/material";
import Table from "./Table";

const TelaEstoque = () => {
    const [openAlert, setOpenAlert] = React.useState(false);
    const navigate = useNavigate();

    const voltar = () => {
        navigate("/tela-inicial");
    };
    
    const handleOpenAlert = () => {
        setOpenAlert(true);
    };

    const handleCloseAlert = () => {
        setOpenAlert(false);
    };

    const Add = async () => {
        try {
            const item = document.getElementById("Item").value;
            const preco = document.getElementById("Preço").value;
            const quantidade = document.getElementById("Quantidade").value;
            if (item === "" || preco === "" || quantidade === "") {
                alert('Preencha todos os campos!');
                return;
            } else {
                const body = {
                    item: item,
                    preco: preco,
                    quantidade: quantidade,
                };
                const response = await axios.post("http://localhost:3010/estoque", body);
                if (response.status === 200) {
                    console.log('Item adicionado com sucesso!');
                    window.location.reload();
                } else {
                    console.error('Erro ao adicionar item:', response.statusText);
                }
            }
        } catch (error) {
            console.error('Erro ao adicionar item:', error.message);
            handleOpenAlert();
        }

    };

    return (
        <div className="divGERAL">
            <div className="faixaVerde" style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
                <img src={Logo} alt="Logo" title="Borado no Campo" width={70} style={{ marginRight: '10px' }} />
                <Button variant='contained' className="btn btn-primary" onClick={voltar}>Voltar</Button>
                <h1 className="titulo" style={{ margin: 'auto' }}>Estoque</h1>
            </div>
            <div className="container-cadastros">
                <Table />
            </div>
            {openAlert && (
                <Alert severity="error" onClose={handleCloseAlert}>
                    <AlertTitle>Error</AlertTitle>
                    Erro ao adicionar item — <b>Verifique a existência de um item com o mesmo nome</b>
                </Alert>
            )}
            <div className="container-cadastros">
                <h2 >Adicionar item ao estoque</h2>
                <div className="container-cadastros">
                    <div className='form'>
                        <div className="form-group">
                            <div className='textFormat'></div>
                            <Input
                                type="text"
                                className="form-control"
                                id="Item"
                                placeholder="Item"
                            />
                        </div>
                    </div>
                    <div className='form'>
                        <div className="form-group">
                            <div className='textFormat'></div>
                            <Input
                                type="number"
                                className="form-control"
                                id="Preço"
                                placeholder="Preço"
                                input={{ min: 0 }}
                            />
                        </div>
                    </div>
                    <div className='form'>
                        <div className="form-group">
                            <div className='textFormat'></div>
                            <Input
                                type="number"
                                className="form-control"
                                id="Quantidade"
                                placeholder="Quantidade"
                                input={{ min: 0 }}
                            />
                        </div>
                    </div>
                </div>
                <Button variant='contained' className="btn btn-primary" onClick={Add}>Adicionar</Button>
            </div>
        </div>
    );
};
export default TelaEstoque;