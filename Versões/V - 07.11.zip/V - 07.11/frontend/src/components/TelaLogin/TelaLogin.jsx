import '../styles.css';
import Logo from "./logo.png";
import axios from 'axios';
import React, { useState } from 'react';
import {useNavigate } from 'react-router-dom';
//material ui
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';

const TelaLogin = ({onLogin}) => {
    const [user, setUser] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();
    const [open, setOpen] = React.useState(false);
    
    const Alert = React.forwardRef(function Alert(props, ref) {
        return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
    });

    const handleClick = () => {
        setOpen(true);
    };

    

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setOpen(false);
    };

    const logar = async () => {
        try {
            const resposta = await axios.post("http://localhost:3010/login", {
                cpf: user,
                senha: password,
            }); 
            console.log(resposta);
			if (resposta.status >= 200 && resposta.status < 300) {
				localStorage.setItem("token", resposta.data.token);
                onLogin();
                navigate('/tela-inicial');
			} else {
				console.error("Falha na autenticação");
			}
            navigate('/tela-inicial');
            
        } catch (erro) {
            handleClick();
            console.error("Erro ao fazer login:", erro.message);
        }
    }

    return (
        <div className="divGERAL">
                <div className='faixaVerde'>
                    <center><h1>Bem-Vindo!</h1></center>
                </div>
                <img src={Logo} alt='logo' title='Bordado no Campo' width={200} />
                <div className='login-container'>
                    <div className='form'>
                        <div className="form-group">
                            <div className='textFormat'>Usuário</div>
                            <input
                                type="user"
                                className="form-control"
                                id="cpf"
                                placeholder="Digite seu Usuário"
                                value={user}
                                onChange={(e) => setUser(e.target.value)}
                            />
                        </div>
                    </div>
                    <div className='form'>
                        <div className="form-group">
                            <div className='textFormat'>Senha</div>
                            <input
                                type="password"
                                className="form-control"
                                id="senha"
                                placeholder="Digite sua senha"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                            />
                        </div>
                    </div>
                    <center><button type="submit" className="btn btn-primary" onClick={logar} >
                        Entrar
                    </button></center>
                </div>
                <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
                    <Alert onClose={handleClose} severity="error" sx={{ width: '100%' }}>
                        Usuário incorreto
                    </Alert>
                </Snackbar>
        </div>
    );
}
export default TelaLogin;    