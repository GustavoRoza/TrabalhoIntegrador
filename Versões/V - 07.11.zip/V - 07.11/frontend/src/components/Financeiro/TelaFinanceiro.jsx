import React, { useState, useEffect } from "react";
import Logo from "./logo.png";
import axios from "axios";
import "../styles.css";
import { useNavigate } from "react-router-dom";
import { Box, Button, TextField, Typography } from "@mui/material";


const TelaFinanceiro = () => {
    const navigate = useNavigate();
    const [entradas, setEntradas] = useState("");
    const [saidas, setSaidas] = useState("");
    const [saldo, setSaldo] = useState(0);
    const [exibirSaldo, setExibirSaldo] = React.useState(0);

    const sair = () => {
        navigate("/tela-inicial");
    };

    const handleEntradasChange = (event) => {
        const input = event.target.value;
        // Filtra para permitir apenas números
        if (/^\d*$/.test(input)) {
            setEntradas(input);
        }
    };

    const handleSaidasChange = (event) => {
        const input = event.target.value;
        // Filtra para permitir apenas números
        if (/^\d*$/.test(input)) {
            setSaidas(input);
        }
    };

    const calcular = async () => {
        const entradasValue = parseInt(entradas) || 0;
        const saidasValue = parseInt(saidas) || 0;
        const novoSaldo = entradasValue - saidasValue;
        setSaldo(novoSaldo);
        if (entradas === "" && saidas === "") {
            alert("Preencha os campos de entradas e saídas");
            return;
        } else {
            try {
                const resultado = await axios.put("http://localhost:3010/saldo",  {saldo: novoSaldo });
                window.location.reload();
                console.log('Atualização bem-sucedida:', resultado);
            } catch (erro) {
                console.error('Erro ao atualizar no banco de dados:', erro);
            }
        }
    };

    const carregarSaldo = async () => {
        try {
            const resposta = await axios.get("http://localhost:3010/saldo");
            const dadosSaldo = resposta.data.saldo;
            console.log('Saldo do banco de dados:', dadosSaldo);
            setExibirSaldo(dadosSaldo);
            // Faça o que precisar com os dados, como atualizar o estado para exibi-los.
        } catch (erro) {
            console.error('Erro ao recuperar o saldo:', erro);
        }
    };

    useEffect(() => {
        carregarSaldo();
    }, []);

    return (
        <div className="divGERAL">
            <div className="faixaVerde">
                <img src={Logo} alt="Logo" title="Borado no Campo" width={70} style={{ marginRight: '10px' }} />
                <Button variant="contained" className="btn btn-primary" onClick={sair}>
                    Voltar
                </Button>
            </div>
            <div className="login-container">
                <Box>
                    <div className="form">
                        <div className="form-group">
                            <Typography className='textFormat'>Entradas</Typography>
                            <TextField
                                type="text"
                                variant="outlined"
                                id="entradas"
                                value={entradas}
                                onChange={handleEntradasChange}
                            />
                        </div>
                    </div>
                </Box>
                <Box>
                    <div className='form'>
                        <div className="form-group">
                            <Typography className='textFormat'>Saídas</Typography>
                            <TextField
                                type="text"
                                variant="outlined"
                                id="saidas"
                                value={saidas}
                                onChange={handleSaidasChange}
                            />
                        </div>
                    </div>
                </Box>
                <center><Button variant="contained" className="btn btn-primary" onClick={calcular} >
                    Calcular
                </Button></center>
                
                <div style={{ textAlign: "center", marginTop: "20px" }}>
                    <Typography variant="h5" color="White">
                        Saldo: {exibirSaldo}

                    </Typography>
                </div>
            </div>

        </div>
    );
};

export default TelaFinanceiro;
