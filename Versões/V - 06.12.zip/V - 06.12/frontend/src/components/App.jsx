import React from 'react';
import axios from 'axios';
import TelaLogin from './TelaLogin/TelaLogin';
import TelaInicial from './TelaInicial/TelaInicial';
import TelaFinanceiro from './Financeiro/TelaFinanceiro';
import { Routes, Route, } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';

axios.defaults.baseURL = "http://localhost:3010/";
axios.defaults.headers.common["Content-Type"] =
  "application/json;charset=utf-8";

function App() {
  const [estaLogado, setEstaLogado] = React.useState(false);
  const navigate = useNavigate();

  React.useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      setEstaLogado(true);
    }
  }, []);

  const handleLogin = () => {
    setEstaLogado(true);
    console.log("Logado:", estaLogado);
  };

  return (
    <div>
      {estaLogado ? (
        <Routes>
          <Route path="/" element={<TelaLogin onLogin={handleLogin} />} />
          <Route path="/tela-inicial" element={<TelaInicial />} />
          <Route path="/tela-financeiro" element={<TelaFinanceiro />} />
        </Routes>
      ) : (
        <TelaLogin onLogin={handleLogin} />
      )}
    </div>


  );
}

export default App;
