import React, { useState } from "react";
import axios from "axios";
import Logo from "./logo.png";
import "../styles.css";
import { useNavigate } from "react-router-dom";
//imports material-ui
import {
    Box,
    Button,
    Container,
    CssBaseline,
    Grid,
    Stack,
} from "@mui/material";

const TelaFinanceiro = () => {
    const navigate = useNavigate();
    const sair = () => {
        navigate("/tela-inicial");
    };

    return (
        <div className="divGERAL">

            <div className="faixaVerde">

                <img src={Logo} alt="Logo" title="Borado no Campo" width={70} style={{ alignItems: 'right' }} />
                <Button variant="outlined"  className="btn btn-primary" onClick={sair}>
                    Voltar
                </Button>

            </div>

            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', backgroundColor: '#9CBA84' }}>
                <Box>
                    <div className="form">
                        <div className="form-group">
                            <div className='textFormat'>Entradas</div>
                            <input
                                type="integer"
                                className="form-control"
                                id="entradas"
                            />
                        </div>
                    </div>

                </Box>
                <Box>
                    <div className='form'>
                        <div className="form-group">
                            <div className='textFormat'>Saídas</div>
                            <input
                                type="integer"
                                className="form-control"
                                id="saidas"
                            />
                        </div>
                    </div>
                </Box>

                
            </div>
            


        </div>
    );
};
export default TelaFinanceiro;

