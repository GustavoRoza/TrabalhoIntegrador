import * as React from "react";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableSortLabel from "@mui/material/TableSortLabel";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import Checkbox from "@mui/material/Checkbox";
import { Modal, Grid, Input } from "@mui/material";
import { styled } from "@mui/system";
import axios from "axios";


const StyledModal = styled(Modal)`
  display: flex;
  align-items: center;
  justify-content: center;
`;

const StyledPaper = styled(Paper)`
  position: absolute;
  width: 400px;
  padding: 16px;
  outline: none;
`;

const StyledInput = styled(Input)`
  width: 100%;
  margin-bottom: 16px;
`;

const fetchDataFromDatabase = async () => {
  try {
    const response = await fetch("http://localhost:3010/pedidos");

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Erro ao buscar dados do banco de dados:", error);
    return [];
  }
};

function createData(usuario, descricao, valor, data, telefone) {
  return {
    usuario,
    descricao,
    valor,
    data,
    telefone,
  };
}
function formatarData(dataString) {
  if (!dataString) {
    return "";
  }

  const data = new Date(dataString);

  if (isNaN(data.getTime())) {
    return "";
  }

  const dia = String(data.getDate()).padStart(2, "0");
  const mes = String(data.getMonth() + 1).padStart(2, "0");
  const ano = data.getFullYear();

  return `${dia}/${mes}/${ano}`;
}

export default function EnhancedTable() {
  const [order, setOrder] = React.useState("asc");
  const [orderBy, setOrderBy] = React.useState("usuario");
  const [open, setOpen] = React.useState(false);
  const [rows, setRows] = React.useState([]);
  const [rowSelected, setRowSelected] = React.useState(null);

  React.useEffect(() => {
    const fetchData = async () => {
      const data = await fetchDataFromDatabase();

      const formattedData = data.map((pedido) =>
        createData(
          pedido.usuario,
          pedido.descricao,
          pedido.preco,
          pedido.data,
          pedido.telefone
        )
      );
      setRows(formattedData);
    };
    fetchData();
  }, []);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
    setRows((prevRows) => {
      return prevRows.slice().sort((a, b) => {
        const aValue =
          typeof a[property] === "number"
            ? a[property]
            : parseFloat(a[property]) || 0;
        const bValue =
          typeof b[property] === "number"
            ? b[property]
            : parseFloat(b[property]) || 0;
        return isAsc ? aValue - bValue : bValue - aValue;
      });
    });
  };

  const handleSelect = (row) => {
    setRowSelected(row);
  };

  const remover = async () => {
    try {
      const resposta = await axios.delete(`http://localhost:3010/pedidos`, {
        data: rowSelected,
      });
      console.log(resposta);
      window.location.reload();
    } catch (error) {
      console.error("Erro ao remover pedido:", error);
    }
  };

  const ModalEdit = ({ isOpen, onClose, rowSelected }) => {
    const [usuario, setUsuario] = React.useState(rowSelected.usuario);
    const [descricao, setDescricao] = React.useState(rowSelected.descricao);
    const [valor, setValor] = React.useState(rowSelected.valor);
    const [data, setData] = React.useState(rowSelected.data);
    const [telefone, setTelefone] = React.useState(rowSelected.telefone);

    const handleSaveChanges = async () => {
      const dataToSend = {
        ...rowSelected,
        usuario,
        descricao,
        valor,
        data,
        telefone,
      };
      console.log("Dados a serem enviados:", dataToSend);

      try {
        const resposta = await axios.put(
          `http://localhost:3010/pedidos`,
          dataToSend
        );

        if (resposta.status === 200) {
          console.log("Pedido atualizado com sucesso!");
          onClose();
          window.location.reload();
        } else {
          console.error("Erro ao atualizar pedido:", resposta.statusText);
        }
      } catch (error) {
        console.error("Erro ao atualizar pedido:", error);
      }
    };
    
    return (
      <StyledModal open={isOpen} onClose={onClose}>
        <StyledPaper>
          <Typography variant="h6" gutterBottom>
            Editar Pedido
          </Typography>
          <Grid container spacing={0}>
            <Grid item xs={12}>
              <StyledInput
                id="Descrição"
                placeholder="Descrição"
                value={descricao}
                onChange={(e) => setDescricao(e.target.value)}
              />
            </Grid>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <StyledInput
                  id="Valor"
                  placeholder="Valor"
                  value={valor}
                  onChange={(e) => setValor(e.target.value)}
                />
              </Grid>
              <Grid item xs={12}>
                <StyledInput
                  id="Data"
                  placeholder="Nova Data (Se necessário alterar)"
                  onChange={(e) => setData(e.target.value)}
                />
              </Grid>
              <Grid item xs={12}>
                <StyledInput
                  id="Telefone"
                  placeholder="Telefone"
                  value={telefone}
                  onChange={(e) => setTelefone(e.target.value)}
                />
              </Grid>
            </Grid>
          </Grid>
          <Box mt={2}>
            <Button
              variant="contained"
              onClick={onClose}
              sx={{ marginRight: 2 }}
            >
              Cancelar
            </Button>
            <Button variant="contained" onClick={handleSaveChanges}>
              Salvar
            </Button>
          </Box>
        </StyledPaper>
      </StyledModal>
    );
  };

  const openModal = () => {
    setOpen(true);
  };

  const closeModal = () => {
    setOpen(false);
  };

  return (
    <Box
      justifyContent="space-between"
      alignItems="center"
      sx={{ width: "100%", maxHeight: "300px", overflow: "auto" }}
    >
      <Paper sx={{ width: "100%", mb: 2 }}>
        <Toolbar
          sx={{
            pl: { sm: 2 },
            pr: { xs: 1, sm: 1 },
          }}
        >
          <Typography
            sx={{ flex: "1 1 100%" }}
            variant="h6"
            id="tableTitle"
            component="div"
          >
            <b>Pedidos</b>
          </Typography>
        </Toolbar>
        <TableContainer>
          <Table
            sx={{ minWidth: 1000 }}
            aria-labelledby="tableTitle"
            size="medium"
          >
            <TableHead>
              <TableRow>
                <TableCell padding="checkbox"> </TableCell>
                <TableCell
                  key="usuario"
                  align="left"
                  padding="normal"
                  sortDirection={orderBy === "usuario" ? order : false}
                >
                  <TableSortLabel
                    active={orderBy === "usuario"}
                    direction={order}
                    onClick={(event) => handleRequestSort(event, "usuario")}
                  >
                    <b>Cliente</b>
                  </TableSortLabel>
                </TableCell>
                <TableCell align="left">
                  <TableSortLabel
                    active={orderBy === "descricao"}
                    direction={order}
                    onClick={(event) => handleRequestSort(event, "descricao")}
                  >
                    <b>Descrição</b>
                  </TableSortLabel>
                </TableCell>
                <TableCell align="left">
                  <TableSortLabel
                    active={orderBy === "valor"}
                    direction={order}
                    onClick={(event) => handleRequestSort(event, "valor")}
                  >
                    <b>Valor</b>
                  </TableSortLabel>
                </TableCell>
                <TableCell align="left">
                  <TableSortLabel
                    active={orderBy === "data"}
                    direction={order}
                    onClick={(event) => handleRequestSort(event, "data")}
                  >
                    <b>Data</b>
                  </TableSortLabel>
                </TableCell>
                <TableCell align="left">
                  <TableSortLabel
                    active={orderBy === "telefone"}
                    direction={order}
                    onClick={(event) => handleRequestSort(event, "telefone")}
                  >
                    <b>Telefone</b>
                  </TableSortLabel>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {rows.map((row) => (
                <TableRow
                  hover
                  key={row.usuario}
                  onClick={() => handleSelect(row)}
                >
                  <TableCell padding="checkbox">
                    <Checkbox
                      color="primary"
                      checked={rowSelected?.usuario === row.usuario}
                      onChange={() => handleSelect(row)}
                    />
                  </TableCell>
                  <TableCell align="left" padding="normal">
                    {row.usuario}
                  </TableCell>
                  <TableCell align="left">{row.descricao}</TableCell>
                  <TableCell align="left">{row.valor}</TableCell>
                  <TableCell align="left">{formatarData(row.data)}</TableCell>
                  <TableCell align="left">{row.telefone}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
      <Button
        disabled={rowSelected === null ? true : false}
        variant="contained"
        onClick={openModal}
        sx={{ marginRight: 2 }}
      >
        Editar
      </Button>
      <Button onClick={remover}> Remover </Button>
      {open && (
        <ModalEdit
          isOpen={openModal}
          onClose={closeModal}
          rowSelected={rowSelected}
        />
      )}
    </Box>
  );
}
