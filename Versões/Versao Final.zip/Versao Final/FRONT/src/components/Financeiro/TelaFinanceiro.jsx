import React, { useState, useEffect } from "react";
import Logo from "../logo.png";
import axios from "axios";
import "../styles.css";
import { useNavigate } from "react-router-dom";
import { Box, Button, TextField, Typography, Container } from "@mui/material";


const TelaFinanceiro = () => {
    const navigate = useNavigate();
    const [entradas, setEntradas] = useState("");
    const [saidas, setSaidas] = useState("");
    const [saldo, setSaldo] = useState(0);
    const [exibirSaldo, setExibirSaldo] = React.useState(0);


    const sair = () => {
        navigate("/tela-inicial");
    };

    const handleEntradasChange = (event) => {
        const input = event.target.value;

        // Verifica se o input é um número ou uma string numérica
        if (/^\d*\.?\d*$/.test(input)) {
            setEntradas(input);
        }
    };

    const handleSaidasChange = (event) => {
        const input = event.target.value;
        // Filtra para permitir apenas números
        if (/^\d*\.?\d*$/.test(input)) {
            setSaidas(input);
        }
    };

    const calcular = async () => {
        const entradasValue = parseInt(entradas) || 0;
        const saidasValue = parseInt(saidas) || 0;
        const novoSaldo = entradasValue - saidasValue;
        setSaldo(novoSaldo);
        if (entradas === "" && saidas === "") {
            alert("Preencha os campos de entradas e saídas");
            return;
        } else {
            try {
                const resultado = await axios.put("http://localhost:3010/saldo", { saldo: novoSaldo });
                window.location.reload();
                console.log('Atualização bem-sucedida:', resultado);
            } catch (erro) {
                console.error('Erro ao atualizar no banco de dados:', erro);
            }
        }
    };

    const carregarSaldo = async () => {
        try {
            const resposta = await axios.get("http://localhost:3010/saldo");
            const dadosSaldo = resposta.data.saldo;
            console.log('Saldo do banco de dados:', dadosSaldo);
            setExibirSaldo(dadosSaldo);

        } catch (erro) {
            console.error('Erro ao recuperar o saldo:', erro);
        }
    };

    useEffect(() => {
        carregarSaldo();
    }, []);

    return (
        <div className="divGERAL">
            <div className="faixaVerde" style={{ display: 'flex', alignItems: 'center' }}>
                <img src={Logo} alt="Logo" title="Borado no Campo" width={70} style={{ marginRight: '10px' }} />
                <Button variant="contained" className="btn btn-primary" onClick={sair}>
                    Voltar
                </Button>
                <h1 className="titulo" style={{ margin: 'auto' }}>Financeiro</h1>
            </div>
            <Container maxWidth="xs" className="container-cadastros">
                <Box mt={5} mb={3}>
                    <div className="form">
                        <div className="form-group">
                            <Typography variant="h6" className='textFormat'>
                                Entradas
                            </Typography>
                            <TextField
                                type="text"
                                variant="outlined"
                                id="entradas"
                                value={entradas}
                                onChange={handleEntradasChange}
                                fullWidth
                            />
                        </div>
                    </div>
                </Box>
                <Box mb={3}>
                    <div className='form'>
                        <div className="form-group">
                            <Typography variant="h6" className='textFormat'>
                                Saídas
                            </Typography>
                            <TextField
                                type="text"
                                variant="outlined"
                                id="saidas"
                                value={saidas}
                                onChange={handleSaidasChange}
                                fullWidth
                            />
                        </div>
                    </div>
                </Box>
                <Box textAlign="center" mb={3}>
                    <Button variant="contained" color="primary" onClick={calcular}>
                        Calcular
                    </Button>
                </Box>
                <div style={{ textAlign: "center", marginTop: "20px" }}>
                    <Typography variant="h5" color="textPrimary">
                        Saldo: {exibirSaldo}
                    </Typography>
                </div>
            </Container>

        </div>
    );
};

export default TelaFinanceiro;
