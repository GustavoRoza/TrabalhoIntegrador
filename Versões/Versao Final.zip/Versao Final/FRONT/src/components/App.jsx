import React from 'react';
import axios from 'axios';
import TelaLogin from './TelaLogin/TelaLogin';
import TelaInicial from './TelaInicial/TelaInicial';
import TelaFinanceiro from './Financeiro/TelaFinanceiro';
import TelaEstoque from './TelaEstoque/TelaEstoque';
import TelaPedidos from './TelaPedidos/TelaPedidos';
import { Routes, Route, } from 'react-router-dom';


axios.defaults.baseURL = "http://localhost:3010/";
axios.defaults.headers.common["Content-Type"] =
  "application/json;charset=utf-8";

function App() {
  const [estaLogado, setEstaLogado] = React.useState(false);


  React.useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      setEstaLogado(true);
    }
  }, []);

  const handleLogin = () => {
    setEstaLogado(true);
    console.log("Logado:", estaLogado);
  };

  return (
    <div>
      {estaLogado ? (
        <Routes>
          <Route path="/" element={<TelaLogin onLogin={handleLogin} />} />
          <Route path="/tela-inicial" element={<TelaInicial />} />
          <Route path="/tela-financeiro" element={<TelaFinanceiro />} />
          <Route path="/tela-estoque" element={<TelaEstoque />} />
          <Route path="/tela-pedidos" element={<TelaPedidos />} />
        </Routes>
      ) : (
        <TelaLogin onLogin={handleLogin} />
      )}
    </div>


  );
}

export default App;
