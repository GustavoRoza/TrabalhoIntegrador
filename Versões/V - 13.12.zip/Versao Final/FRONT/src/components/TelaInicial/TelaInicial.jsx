import React, { useState, useEffect } from "react";
import '../styles.css';
import Logo from '../logo.png';
import { useNavigate } from 'react-router-dom';

// import dos botões do material ui
import BottomNavigation from '@mui/material/BottomNavigation';
import BottomNavigationAction from '@mui/material/BottomNavigationAction';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';
import InventoryIcon from '@mui/icons-material/Inventory';
import ProductionQuantityLimitsIcon from '@mui/icons-material/ProductionQuantityLimits';
// material ui
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';

const TelaInicial = () => {
  const [value, setValue] = React.useState('null');
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  
  const Alert = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
  });

  const handleClick = () => {
    setOpen(true);
  };

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpen(false);
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
  };

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      handleClick();
    } else {  
      navigate("/");
    }
  },[] );
  
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleSair = () => {
    handleLogout();
  };

  const handleFinanceiro = () => {
    navigate("/tela-financeiro");
  };

  const handleEstoque = () => {
    navigate("/tela-estoque");
  };
  const handlePedidos = () => {
    navigate("/tela-pedidos");
  };
  return (
    <div>
      <div className="faixaVerde" style={{ display: 'flex', alignItems: 'center' }}>
                <img src={Logo} alt="Logo" title="Borado no Campo" width={70} style={{ marginRight: '10px' }} />
                <h1 className="titulo"  style={{ margin: 'auto', color: 'white'}}>Início</h1>
            </div>
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', backgroundColor: '#9CBA84' }}>
        <BottomNavigation sx={{ width: 500, backgroundColor: '#D9D9D9' }} value={value} onChange={handleChange}>
          <BottomNavigationAction
            label="Financeiro"
            value="recents"
            icon={<AccountBalanceWalletIcon />}
            sx={{ '& .MuiBottomNavigationAction-label': { opacity: 1 }, '&:hover': { backgroundColor: '#A9A9A9' } }}
            onClick={handleFinanceiro}
          />
          <BottomNavigationAction
            label="Pedidos"
            value="favorites"
            icon={<ProductionQuantityLimitsIcon />}
            sx={{ '& .MuiBottomNavigationAction-label': { opacity: 1 }, '&:hover': { backgroundColor: '#A9A9A9' } }}
            onClick={handlePedidos}
          />
          <BottomNavigationAction
            label="Estoque"
            value="nearby"
            icon={<InventoryIcon />}
            sx={{ '& .MuiBottomNavigationAction-label': { opacity: 1 }, '&:hover': { backgroundColor: '#A9A9A9' } }}
            onClick={handleEstoque}
          />
          <BottomNavigationAction
            label="Sair"
            value="folder"
            icon={<ExitToAppIcon />}
            sx={{ '& .MuiBottomNavigationAction-label': { opacity: 1 }, '&:hover': { backgroundColor: '#A9A9A9' } }}
            onClick={handleSair}
          />
        </BottomNavigation>
      </div>
      <Snackbar open={open} autoHideDuration={6000} onClose={handleClose}>
        <Alert onClose={handleClose} severity="success" sx={{ width: '100%' }}>
          Login realizado com sucesso!
        </Alert>
      </Snackbar>
    </div>
  );
}

export default TelaInicial;
