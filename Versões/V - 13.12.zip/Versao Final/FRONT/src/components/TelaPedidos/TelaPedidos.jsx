import React from "react";
import axios from "axios";
import "../styles.css";
import Logo from "../logo.png";
import { useNavigate } from "react-router-dom";
import { Button, Input, Alert, AlertTitle } from "@mui/material";
import Table from "./Table";

const TelaPedidos = () => {
  const [openAlert, setOpenAlert] = React.useState(false);
  const navigate = useNavigate();

  const voltar = () => {
    navigate("/tela-inicial");
  };

  const handleOpenAlert = () => {
    setOpenAlert(true);
  };

  const handleCloseAlert = () => {
    setOpenAlert(false);
  };

  const Add = async () => {
    try {
      const usuario = document.getElementById("Usuario").value;
      const descricao = document.getElementById("Descrição").value;
      const valor = document.getElementById("Valor").value;
      const data = document.getElementById("Data").value;
      const telefone = document.getElementById("Telefone").value;

      if (
        usuario === "" ||
        descricao === "" ||
        valor === "" ||
        data === "" ||
        telefone === ""
      ) {
        alert("Preencha todos os campos!");
        return;
      } else {
        const body = {
          usuario: usuario,
          descricao: descricao,
          preco: valor,
          data: data,
          telefone: telefone,
        };
        const response = await axios.post(
          "http://localhost:3010/pedidos",
          body
        );

        if (response.status === 200) {
          console.log("Pedido adicionado com sucesso!");
          window.location.reload();
        } else {
          console.error("Erro ao adicionar pedido:", response.statusText);
        }
      }
    } catch (error) {
      console.error("Erro ao adicionar pedido:", error.message);
      handleOpenAlert();
    }
  };

  return (
    <div className="divGERAL">
      <div
        className="faixaVerde"
        style={{ display: "flex", alignItems: "center", marginBottom: "10px" }}
      >
        <img
          src={Logo}
          alt="Logo"
          title="Borado no Campo"
          width={70}
          style={{ marginRight: "10px" }}
        />
        <Button
          variant="contained"
          className="btn btn-primary"
          onClick={voltar}
        >
          Voltar
        </Button>
        <h1 className="titulo" style={{ margin: "auto" }}>
          Pedidos
        </h1>
      </div>
      <div className="container-cadastros">
        <div className="cadastro">
          <h2 className="titulo-cadastro">Cadastro de Pedidos</h2>
          <div className="inputs">
            <Input id="Usuario" placeholder="Cliente" />
            <Input id="Descrição" placeholder="Descrição" />
            <Input id="Valor" placeholder="Valor" />
            <Input id="Data" placeholder="Data" />
            <Input id="Telefone" placeholder="Telefone" />
          </div>
          <Button
            style={{ marginTop: "10px" }}
            variant="contained"
            className="btn btn-primary"
            onClick={Add}
          >
            Adicionar
          </Button>
        </div>
      </div>
      <div className="container-cadastros">
        <Table />
      </div>
      {openAlert && (
        <Alert severity="error" onClose={handleCloseAlert}>
          <AlertTitle>Error</AlertTitle>
          Erro ao adicionar pedido —{" "}
          <b>Verifique se não há um pedido com o mesmo cliente. 
            Caso haja, edite o pedido já existente.
            Ou insira uma data válida!
          </b>
        </Alert>
      )}
    </div>
  );
};

export default TelaPedidos;
