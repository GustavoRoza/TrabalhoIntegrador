import React, { useState } from 'react';
import TelaLogin from './TelaLogin/TelaLogin';
import axios from 'axios';
import TelaInicial from './TelaInicial/TelaInicial';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';

axios.defaults.baseURL = "http://localhost:3010/";
axios.defaults.headers.common["Content-Type"] =
  "application/json;charset=utf-8";

function App() {

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<TelaLogin />}/>
        <Route path="/tela-inicial" element={<TelaInicial />} />
      </Routes>
    </Router>
  );
}

export default App;
