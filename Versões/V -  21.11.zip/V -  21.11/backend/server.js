const express = require('express');
const cors = require('cors');
const axios = require('axios');
const app = express();
const PORT = process.env.PORT || 3010;
app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.send('Servidor backend funcionando!');
});

app.listen(PORT, () => {
  console.log(`Servidor backend rodando na porta ${PORT}`);
});



app.post('/login', (req, res) => {
    const { user, password } = req.body;
    
    if (user === 'Administrador' && password === 'teste123') {
      res.status(200).json({ message: 'Login efetuado com sucesso!' });
      
    }else{
        res.status(401).json({ message: 'Usuário ou senha inválidos!' });
    }
});

app.post('/inicio', (req, res) => {
  estaLogado = req.body.estaLogado;
  if(estaLogado){
    res.status(200).json({ message: 'Login efetuado com sucesso!' });
  }
});



